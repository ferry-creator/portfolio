﻿=== Wii Cursor Set ===

By: Adri34y5 (http://www.rw-designer.com/user/111242)

Download: http://www.rw-designer.com/cursor-set/wii

Author's description:

This are the traditional cursors of the Nintendo Wii.
I have more color variations:
http://www.rw-designer.com/cursor-set/wii-red
http://www.rw-designer.com/cursor-set/wii-light-green
http://www.rw-designer.com/cursor-set/wii-yellow

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.
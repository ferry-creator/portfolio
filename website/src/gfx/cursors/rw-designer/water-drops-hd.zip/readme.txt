﻿=== Water Drops HD Cursor Set ===

By: Ludwig (http://www.rw-designer.com/user/39002) e1839365@rmqkr.net

Download: http://www.rw-designer.com/cursor-set/water-drops-hd

Author's description:

A high quality, animated cursor set resembling water drops. Free for use, no attribution required.

== Every cursor is available in two sizes: 32x32 and 48x48 [[image:icon-image/10147-24x24x32.png]] ==

Choose the higher definition on high-res displays.

For the '''link cursor''', you can choose your favourite colour!

=== The simple but elegant design, combined with subtle animations, is perfect for your everyday work. ===

The hotspot in the center is unconventional, but you'll get used to it very quickly. Because the cursors are transparent, you can still see what you're clicking on. I also made sure it looks good on a dark background.

When installing this on '''Windows''', you should disable the cursor shadow.

This cursor set works on Linux, I'll provide help for setting it up shortly.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.
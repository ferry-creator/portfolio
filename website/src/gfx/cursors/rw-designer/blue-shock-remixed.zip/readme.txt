﻿=== Blue Shock ⚫ Cursor Set ===

By: AJaxx (http://www.rw-designer.com/user/56600) cyberjack66@yahoo.com

Download: http://www.rw-designer.com/cursor-set/blue-shock-remixed

Author's description:

A fun, Legacy cursorFX set from 2005 converted for windows. Added extra/bonus cursors, animations & sizes/static cursors for user enjoyment.

Credit: Lpg85
http://www.wincustomize.com/explore/cursorfx/1593/

Have fun & enjoy!
[[cursor:81696]]

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.
﻿=== Gem Cursor Set ===

By: JDDellGuy (http://www.rw-designer.com/user/14944) josiah_deal@yahoo.com

Download: http://www.rw-designer.com/cursor-set/gem-cursors

Author's decription:

A set of gem cursors that I have made using Blender and RealWorld Cursor Editor.  They are Glassy and reflective in appearance.  I spent a great deal of effort on them, and came to know about that wonderful problem with 3D software called gimbal lock.  Fortunately, I learned that setting my rotation mode to use quaternions solves that issue very rapidly.

Your choice of four colors.  You all are going to be saying things like "That's not red, it's pink!" or "How is a clearish color black?"
Here is why.  The colors that I used to get the appearance is what I named them.  I applied a lot of Fresnel to these in order to get the glass effect.  This basically restricts the color to the edges of the 3D models making it look lighter in appearance.

If anybody is interested in the files that I used to make these (I keep all my blender files, rendered images, and PNG strips organized in a folder) let me know and I may be able to send them to you in a .zip file.

=== Don't forget to rate and comment! ===

Enjoy!  :-)

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.
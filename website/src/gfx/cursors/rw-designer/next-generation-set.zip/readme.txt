﻿=== Next Generation Cursor Set ===

By: Troy

Download: http://www.rw-designer.com/cursor-set/next-generation-set

Author's decription:

Next Generation Cursor Set is my latest cursor set. It involves STYLISH designs, VIBRANT colours and INNOVATIVE ideas. The simple cursor of Next Generation challenges the conventional angle of a pointer while still remaining completely functional and user friendly. I have also implemented some Mac cursor designs that i thought best suit Next Generation. Next Generation provides a variety of loading cursor for complete satisfaction. Next Generation is a definite MUST HAVE cursor set and i am sure it will suite all desktop interfaces. 
PS. Please post any SUGGESTIONS, COMMENTS, DESIRES, OPINIONS, etc. All comments will be greatly appreciated and used for designing later cursor sets. Regards, Troy


==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
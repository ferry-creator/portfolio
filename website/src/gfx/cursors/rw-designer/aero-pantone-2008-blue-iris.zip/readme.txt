﻿=== aero-pantone-2008-blue-iris Cursor Set ===

By: 4qts (http://www.rw-designer.com/user/54280) cgallon@gmail.com

Download: http://www.rw-designer.com/cursor-set/aero-pantone-2008-blue-iris

Author's description:

Aero 32x32 based on Pantone 2008 color of the year Blue Iris 

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.
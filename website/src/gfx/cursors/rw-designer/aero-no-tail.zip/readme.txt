﻿=== Windows Aero No Tail Cursor Set ===

By: benjy2429 (http://www.rw-designer.com/user/4292)

Download: http://www.rw-designer.com/cursor-set/aero-no-tail

Author's decription:

A little remake of the Windows Aero cursor set ;)
2nd Cursor Set! Also available in Left Handed on request.

==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
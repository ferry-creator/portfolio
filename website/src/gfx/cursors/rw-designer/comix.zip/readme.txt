﻿=== Comix Cursor Set ===

By: 

Download: http://www.rw-designer.com/cursor-set/comix

Author's decription:

A port of the Linux Comix cursors. The original set contains cursors in multiple resolutions and colors. To use different size or color, download [http://www.kde-look.org/content/show.php?content=32627 the original set] and convert the cursors to Windows format with [[cursor-maker|RealWorld Cursor Editor 2007.1]].

The cursors are distributed under the GPL license ([http://www.fsf.org/licenses/gpl.html]).

==========

License: Creative Commons - Attribution + Share Alike

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
* Share Alike - If you alter, transform, or build upon this work,
  you may distribute the resulting work only under the same, similar
  or a compatible license.
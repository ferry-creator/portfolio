﻿=== Clear BlueGlass Cursor Set ===

By: TheMouseMan (http://www.rw-designer.com/user/1279) daniel_anzaldo@yahoo.com

Download: http://www.rw-designer.com/cursor-set/clear-blueglass

Author's decription:

This is set to a MS Vista appearance with shadows included, created with RealWorld Cursor Editor 2006.1 and IcoFX 1.5.01(unfortunately because I don't have a RealWorld Icon Creator copy). All cursors translucent.

==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
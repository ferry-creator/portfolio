﻿=== Blue Aero Cursor Set ===

By: hlark324 (http://www.rw-designer.com/user/6234) hsun324@gmail.com

Download: http://www.rw-designer.com/cursor-set/blue-aero-cursors

Author's decription:

Cursors modeled after the aero cursors in vista. Completely drawn by hand and is very usable.

==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
﻿=== Round Frutiger Aero Inspired Cursor Set ===

By: LegionEaglesRae (http://www.rw-designer.com/user/115644)

Download: http://www.rw-designer.com/cursor-set/round-frutiger-aero-inspired

Author's description:

I had fun making this one. I made it blue, because that's the colour I think of when I think of round things. Enjoy!

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.